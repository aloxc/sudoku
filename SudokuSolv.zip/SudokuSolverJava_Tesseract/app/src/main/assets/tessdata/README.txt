请将官方 Tesseract tessdata 的 eng.traineddata 放到本目录：
app/src/main/assets/tessdata/eng.traineddata

本项目不内置该二进制模型文件；运行时完全离线，模型会随 APK 打包。
建议使用与 Tesseract 4/5 兼容的官方 eng.traineddata。
