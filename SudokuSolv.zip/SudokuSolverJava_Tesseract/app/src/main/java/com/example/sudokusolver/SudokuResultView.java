package com.example.sudokusolver;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

public class SudokuResultView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int[][] original=new int[9][9];
    private int[][] solved=new int[9][9];

    public SudokuResultView(Context c){super(c); p.setTypeface(Typeface.DEFAULT);}
    public void setData(int[][] o,int[][] s){original=copy(o);solved=copy(s);invalidate();}

    private int[][] copy(int[][] a){
        int[][] x=new int[9][9];
        for(int r=0;r<9;r++) System.arraycopy(a[r],0,x[r],0,9);
        return x;
    }

    @Override protected void onDraw(Canvas c){
        float w=getWidth()/9f,h=getHeight()/9f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE); c.drawRect(0,0,getWidth(),getHeight(),p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        for(int r=0;r<9;r++) for(int col=0;col<9;col++){
            int v=solved[r][col];
            if(v==0) continue;
            p.setTextSize(Math.min(w,h)*.58f);
            p.setColor(original[r][col]==0 ? 0xFF6750A4 : Color.BLACK);
            c.drawText(String.valueOf(v),col*w+w/2,r*h+h*.68f,p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2);
        p.setColor(Color.BLACK);
        for(int i=0;i<=9;i++){
            p.setStrokeWidth(i%3==0?5:1.5f);
            c.drawLine(i*w,0,i*w,getHeight(),p);
            c.drawLine(0,i*h,getWidth(),i*h,p);
        }
    }
}
