package com.example.sudokusolver;

public final class SudokuSolver {
    private SudokuSolver() {}

    public static boolean isValid(int[][] a) {
        for (int r=0;r<9;r++) {
            boolean[] seen=new boolean[10];
            for(int c=0;c<9;c++) {
                int v=a[r][c];
                if(v<0||v>9) return false;
                if(v!=0 && seen[v]) return false;
                if(v!=0) seen[v]=true;
            }
        }
        for (int c=0;c<9;c++) {
            boolean[] seen=new boolean[10];
            for(int r=0;r<9;r++) {
                int v=a[r][c];
                if(v!=0 && seen[v]) return false;
                if(v!=0) seen[v]=true;
            }
        }
        for(int br=0;br<9;br+=3) for(int bc=0;bc<9;bc+=3) {
            boolean[] seen=new boolean[10];
            for(int r=br;r<br+3;r++) for(int c=bc;c<bc+3;c++) {
                int v=a[r][c];
                if(v!=0 && seen[v]) return false;
                if(v!=0) seen[v]=true;
            }
        }
        return true;
    }

    public static boolean solve(int[][] a) {
        int bestR=-1,bestC=-1,bestCount=10;
        for(int r=0;r<9;r++) for(int c=0;c<9;c++) if(a[r][c]==0) {
            int count=0;
            for(int n=1;n<=9;n++) if(can(a,r,c,n)) count++;
            if(count==0) return false;
            if(count<bestCount){bestCount=count;bestR=r;bestC=c;}
        }
        if(bestR==-1) return true;

        for(int n=1;n<=9;n++) if(can(a,bestR,bestC,n)) {
            a[bestR][bestC]=n;
            if(solve(a)) return true;
            a[bestR][bestC]=0;
        }
        return false;
    }

    private static boolean can(int[][] a,int r,int c,int n) {
        for(int i=0;i<9;i++) {
            if(a[r][i]==n || a[i][c]==n) return false;
        }
        int br=r/3*3,bc=c/3*3;
        for(int rr=br;rr<br+3;rr++) for(int cc=bc;cc<bc+3;cc++)
            if(a[rr][cc]==n) return false;
        return true;
    }
}
