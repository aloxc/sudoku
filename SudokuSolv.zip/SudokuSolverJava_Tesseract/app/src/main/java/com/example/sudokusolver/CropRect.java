package com.example.sudokusolver;

import android.graphics.RectF;

public final class CropRect {
    private CropRect() {}

    public static RectF clamp(RectF r) {
        RectF x = new RectF(r);
        x.left = Math.max(0f, Math.min(1f, x.left));
        x.top = Math.max(0f, Math.min(1f, x.top));
        x.right = Math.max(0f, Math.min(1f, x.right));
        x.bottom = Math.max(0f, Math.min(1f, x.bottom));
        if (x.right < x.left) {
            float t = x.left; x.left = x.right; x.right = t;
        }
        if (x.bottom < x.top) {
            float t = x.top; x.top = x.bottom; x.bottom = t;
        }
        return x;
    }

    public static RectF defaultRect() {
        return new RectF(0.08f, 0.20f, 0.92f, 0.80f);
    }
}
