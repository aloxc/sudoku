package com.example.sudokusolver;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class CropOverlayView extends View {
    private final Paint shade = new Paint();
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handle = new Paint(Paint.ANTI_ALIAS_FLAG);

    private RectF normalized = CropRect.defaultRect();
    private RectF startRect = new RectF();
    private float downX, downY;
    private int mode = 0; // 0 none, 1 move, 2 left, 3 top, 4 right, 5 bottom, corners 6-9
    private boolean enabled = true;

    public CropOverlayView(Context c, AttributeSet a) {
        super(c, a);
        shade.setColor(0x99000000);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(5f);
        border.setColor(Color.WHITE);
        handle.setColor(0xFF6750A4);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setNormalizedRect(RectF r) {
        normalized = CropRect.clamp(r);
        invalidate();
    }

    public RectF getNormalizedRect() {
        return new RectF(normalized);
    }

    public void setEditingEnabled(boolean value) {
        enabled = value;
        invalidate();
    }

    private RectF actual() {
        return new RectF(
                normalized.left * getWidth(),
                normalized.top * getHeight(),
                normalized.right * getWidth(),
                normalized.bottom * getHeight());
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (!enabled) return;
        RectF r = actual();

        c.drawRect(0, 0, getWidth(), r.top, shade);
        c.drawRect(0, r.bottom, getWidth(), getHeight(), shade);
        c.drawRect(0, r.top, r.left, r.bottom, shade);
        c.drawRect(r.right, r.top, getWidth(), r.bottom, shade);

        c.drawRect(r, border);

        float s = 18f;
        c.drawCircle(r.left, r.top, s, handle);
        c.drawCircle(r.right, r.top, s, handle);
        c.drawCircle(r.left, r.bottom, s, handle);
        c.drawCircle(r.right, r.bottom, s, handle);
    }

    private int hit(float x, float y) {
        RectF r = actual();
        float d = 35f;
        boolean l = Math.abs(x-r.left)<d, rr = Math.abs(x-r.right)<d;
        boolean t = Math.abs(y-r.top)<d, b = Math.abs(y-r.bottom)<d;
        if (l && t) return 6;
        if (rr && t) return 7;
        if (l && b) return 8;
        if (rr && b) return 9;
        if (l && y>=r.top && y<=r.bottom) return 2;
        if (rr && y>=r.top && y<=r.bottom) return 4;
        if (t && x>=r.left && x<=r.right) return 3;
        if (b && x>=r.left && x<=r.right) return 5;
        if (r.contains(x,y)) return 1;
        return 0;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!enabled) return false;
        float x=e.getX(), y=e.getY();
        if (e.getAction()==MotionEvent.ACTION_DOWN) {
            downX=x; downY=y; startRect=new RectF(normalized);
            mode=hit(x,y);
            return mode!=0;
        }
        if (e.getAction()==MotionEvent.ACTION_MOVE && mode!=0) {
            float dx=(x-downX)/Math.max(1,getWidth());
            float dy=(y-downY)/Math.max(1,getHeight());
            RectF r=new RectF(startRect);
            if(mode==1) r.offset(dx,dy);
            if(mode==2||mode==6||mode==8) r.left += dx;
            if(mode==4||mode==7||mode==9) r.right += dx;
            if(mode==3||mode==6||mode==7) r.top += dy;
            if(mode==5||mode==8||mode==9) r.bottom += dy;

            r=CropRect.clamp(r);
            float min=.03f;
            if(r.width()<min) {
                if(mode==2||mode==6||mode==8) r.left=r.right-min;
                else r.right=r.left+min;
            }
            if(r.height()<min) {
                if(mode==3||mode==6||mode==7) r.top=r.bottom-min;
                else r.bottom=r.top+min;
            }
            normalized=CropRect.clamp(r);
            invalidate();
            return true;
        }
        if(e.getAction()==MotionEvent.ACTION_UP) {
            mode=0;
            performClick();
            return true;
        }
        return true;
    }
}
