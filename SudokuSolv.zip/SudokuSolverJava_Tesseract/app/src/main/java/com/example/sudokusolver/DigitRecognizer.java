package com.example.sudokusolver;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/**
 * Fully offline digit recognizer based on Tesseract OCR.
 *
 * The recognizer is intentionally constrained to digits 1-9.
 * Each Sudoku cell is preprocessed before OCR:
 *  - grayscale
 *  - remove the outer border area
 *  - threshold to black/white
 *  - reject cells with too little ink as blank
 *
 * Put tessdata/eng.traineddata in app/src/main/assets/tessdata/.
 * The traineddata file is copied to the app's private files directory on first use.
 */
public class DigitRecognizer {
    private static final String LANG = "eng";
    private static final String DATA_DIR = "tessdata";
    private static final double BLANK_INK_RATIO = 0.012;
    private static final double VERY_DENSE_INK_RATIO = 0.65;

    private final Context context;
    private TessBaseAPI tessBaseAPI;

    public DigitRecognizer(Context context) {
        this.context = context.getApplicationContext();
    }

    public void init() throws IOException {
        File baseDir = new File(context.getFilesDir(), "tesseract");
        File tessDataDir = new File(baseDir, DATA_DIR);
        if (!tessDataDir.exists() && !tessDataDir.mkdirs()) {
            throw new IOException("无法创建 Tesseract tessdata 目录");
        }

        File trainedData = new File(tessDataDir, LANG + ".traineddata");
        if (!trainedData.exists()) {
            copyAsset("tessdata/" + LANG + ".traineddata", trainedData);
        }

        tessBaseAPI = new TessBaseAPI();
        if (!tessBaseAPI.init(baseDir.getAbsolutePath(), LANG)) {
            tessBaseAPI.end();
            tessBaseAPI = null;
            throw new IOException("Tesseract 初始化失败，请检查 tessdata/eng.traineddata");
        }

        tessBaseAPI.setPageSegMode(TessBaseAPI.PSM_SINGLE_CHAR);
        tessBaseAPI.setVariable(
                TessBaseAPI.VAR_CHAR_WHITELIST,
                "123456789"
        );
        tessBaseAPI.setVariable(
                "classify_bln_numeric_mode",
                "1"
        );
    }

    public int recognizeDigit(Bitmap cellBitmap) {
        if (tessBaseAPI == null) {
            throw new IllegalStateException("DigitRecognizer 尚未 init()");
        }

        Bitmap prepared = preprocessCell(cellBitmap);
        if (prepared == null) {
            return 0;
        }

        tessBaseAPI.setImage(prepared);
        String text = tessBaseAPI.getUTF8Text();
        float confidence = tessBaseAPI.meanConfidence();
        tessBaseAPI.clear();

        prepared.recycle();

        if (text == null) return 0;

        text = text.trim().replaceAll("[^1-9]", "");
        if (text.length() != 1) return 0;

        int digit = text.charAt(0) - '0';

        // Low-confidence OCR is treated as blank/unknown so the user
        // can correct it in the confirmation grid instead of silently
        // inserting a bad digit.
        if (confidence >= 45.0f) {
            return digit;
        }
        return 0;
    }

    private Bitmap preprocessCell(Bitmap src) {
        int w = src.getWidth();
        int h = src.getHeight();
        if (w < 8 || h < 8) return null;

        // Ignore a small perimeter so Sudoku grid lines do not become
        // part of the OCR character.
        int marginX = Math.max(2, Math.round(w * 0.12f));
        int marginY = Math.max(2, Math.round(h * 0.12f));
        int left = marginX;
        int top = marginY;
        int right = w - marginX;
        int bottom = h - marginY;
        if (right <= left || bottom <= top) return null;

        Bitmap gray = Bitmap.createBitmap(
                src, left, top, right - left, bottom - top,
                null, false
        );

        int gw = gray.getWidth();
        int gh = gray.getHeight();
        int[] pixels = new int[gw * gh];
        gray.getPixels(pixels, 0, gw, 0, 0, gw, gh);

        long sum = 0;
        for (int i = 0; i < pixels.length; i++) {
            int r = Color.red(pixels[i]);
            int g = Color.green(pixels[i]);
            int b = Color.blue(pixels[i]);
            int y = (299 * r + 587 * g + 114 * b) / 1000;
            pixels[i] = y;
            sum += y;
        }
        double mean = sum / (double) pixels.length;

        // A simple local threshold. Sudoku screenshots usually have
        // a light background with dark glyphs.
        int threshold = (int) Math.max(90, Math.min(210, mean * 0.72));

        int ink = 0;
        for (int i = 0; i < pixels.length; i++) {
            int y = pixels[i];
            if (y < threshold) {
                pixels[i] = Color.BLACK;
                ink++;
            } else {
                pixels[i] = Color.WHITE;
            }
        }

        double inkRatio = ink / (double) pixels.length;
        gray.setPixels(pixels, 0, gw, 0, 0, gw, gh);

        if (inkRatio < BLANK_INK_RATIO || inkRatio > VERY_DENSE_INK_RATIO) {
            gray.recycle();
            return null;
        }

        // Scale up to make small screenshot digits easier for Tesseract.
        int outSize = 128;
        Bitmap scaled = Bitmap.createScaledBitmap(gray, outSize, outSize, true);
        gray.recycle();

        // Add a white border around the glyph for PSM_SINGLE_CHAR.
        Bitmap padded = Bitmap.createBitmap(160, 160, Bitmap.Config.ARGB_8888);
        padded.eraseColor(Color.WHITE);
        android.graphics.Canvas canvas = new android.graphics.Canvas(padded);
        canvas.drawBitmap(scaled, 16, 16, null);
        scaled.recycle();

        return padded;
    }

    private void copyAsset(String assetPath, File target) throws IOException {
        try (InputStream in = context.getAssets().open(assetPath);
             FileOutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
            }
        }
    }

    public void close() {
        if (tessBaseAPI != null) {
            tessBaseAPI.end();
            tessBaseAPI = null;
        }
    }
}
