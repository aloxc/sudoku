package com.example.sudokusolver;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private DigitRecognizer digitRecognizer;
    private ImageView imageView;
    private CropOverlayView cropOverlay;
    private TextView hint;
    private Bitmap sourceBitmap;
    private SharedPreferences prefs;
    private boolean manualCropMode=true;
    private ExecutorService executor=Executors.newSingleThreadExecutor();
    private DigitRecognizer recognizer;

    private final ActivityResultLauncher<Intent> picker =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if(result.getResultCode()!=RESULT_OK || result.getData()==null) return;
                Uri uri=result.getData().getData();
                if(uri==null) return;
                try {
                    getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch(Exception ignored){}
                loadImage(uri);
            });

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        digitRecognizer = new DigitRecognizer(this);
        try {
            digitRecognizer.init();
        } catch (Exception e) {
            Toast.makeText(this, "Tesseract 初始化失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        imageView=findViewById(R.id.imageView);
        cropOverlay=findViewById(R.id.cropOverlay);
        hint=findViewById(R.id.txtHint);
        Button select=findViewById(R.id.btnSelect);
        Button reset=findViewById(R.id.btnReset);
        Button recognize=findViewById(R.id.btnRecognize);

        prefs=getSharedPreferences("sudoku",MODE_PRIVATE);
        recognizer=new DigitRecognizer();

        cropOverlay.setNormalizedRect(loadRect());
        select.setOnClickListener(v->pickImage());
        reset.setOnClickListener(v->{
            manualCropMode=true;
            cropOverlay.setEditingEnabled(true);
            cropOverlay.setNormalizedRect(loadRect());
            hint.setText("请拖动四个角或边缘，框选整个九宫格。");
        });
        recognize.setOnClickListener(v->startRecognition());
    }

    private RectF loadRect(){
        return new RectF(
                prefs.getFloat("l",0.08f),
                prefs.getFloat("t",0.20f),
                prefs.getFloat("r",0.92f),
                prefs.getFloat("b",0.80f));
    }

    private void saveRect(RectF r){
        prefs.edit().putFloat("l",r.left).putFloat("t",r.top)
                .putFloat("r",r.right).putFloat("b",r.bottom).apply();
    }

    private void pickImage(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        picker.launch(i);
    }

    private void loadImage(Uri uri){
        try(InputStream in=getContentResolver().openInputStream(uri)){
            sourceBitmap=BitmapFactory.decodeStream(in);
            imageView.setImageBitmap(sourceBitmap);
            manualCropMode=true;
            cropOverlay.setEditingEnabled(true);
            RectF saved=loadRect();
            cropOverlay.setNormalizedRect(saved);
            hint.setText("已载入截图。拖动框选九宫格；框选位置会自动记住。");
        }catch(Exception e){
            Toast.makeText(this,"读取图片失败："+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void startRecognition(){
        if(sourceBitmap==null){
            Toast.makeText(this,"请先选择一张截图。",Toast.LENGTH_SHORT).show();
            return;
        }

        RectF r=cropOverlay.getNormalizedRect();
        saveRect(r);
        cropOverlay.setEditingEnabled(false);
        hint.setText("正在切割、识别 81 个格子，请稍候……");

        executor.execute(()->{
            Bitmap grid=ImageUtils.crop(sourceBitmap,r);
            int[][] puzzle=new int[9][9];

            for(int row=0;row<9;row++){
                for(int col=0;col<9;col++){
                    Bitmap cell=ImageUtils.cell(grid,row,col);
                    puzzle[row][col]=recognizer.recognize(cell);
                    cell.recycle();
                }
            }
            grid.recycle();

            runOnUiThread(()->showRecognized(puzzle));
        });
    }

    private void showRecognized(int[][] puzzle){
        if(!SudokuSolver.isValid(puzzle)){
            cropOverlay.setEditingEnabled(true);
            hint.setText("识别结果存在冲突，请检查框选区域或重新识别。");
            showGridEditor(puzzle,"识别结果有冲突，请修改后再计算。");
            return;
        }

        showGridEditor(puzzle,"请确认识别结果。点击“计算答案”后会填充空白格。");
    }

    private void showGridEditor(int[][] puzzle,String message){
        final String[] labels=new String[81];
        for(int r=0;r<9;r++) for(int c=0;c<9;c++)
            labels[r*9+c]=puzzle[r][c]==0 ? "" : String.valueOf(puzzle[r][c]);

        android.widget.GridLayout grid=new android.widget.GridLayout(this);
        grid.setColumnCount(9);
        grid.setRowCount(9);
        int size=(int)(getResources().getDisplayMetrics().density*42);

        android.widget.EditText[] edits=new android.widget.EditText[81];
        for(int i=0;i<81;i++){
            android.widget.EditText e=new android.widget.EditText(this);
            e.setText(labels[i]);
            e.setTextSize(18);
            e.setGravity(android.view.Gravity.CENTER);
            e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            android.widget.GridLayout.LayoutParams lp=new android.widget.GridLayout.LayoutParams();
            lp.width=size; lp.height=size;
            e.setLayoutParams(lp);
            edits[i]=e; grid.addView(e);
        }

        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("识别结果")
                .setMessage(message)
                .setView(grid)
                .setNegativeButton("取消",(d,w)->{
                    cropOverlay.setEditingEnabled(true);
                    hint.setText("可以重新调整框选区域。");
                })
                .setPositiveButton("计算答案",null)
                .create();

        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int[][] a=new int[9][9];
            boolean bad=false;
            for(int i=0;i<81;i++){
                String s=edits[i].getText().toString().trim();
                int n=0;
                if(!s.isEmpty()){
                    try{n=Integer.parseInt(s);}catch(Exception ex){bad=true;}
                    if(n<1||n>9) bad=true;
                }
                a[i/9][i%9]=n;
            }
            if(bad||!SudokuSolver.isValid(a)){
                Toast.makeText(this,"请检查：每个格子只能是 1～9，且不能有重复数字。",Toast.LENGTH_LONG).show();
                return;
            }
            int[][] solved=new int[9][9];
            for(int rr=0;rr<9;rr++) System.arraycopy(a[rr],0,solved[rr],0,9);
            if(!SudokuSolver.solve(solved)){
                Toast.makeText(this,"这个数独没有找到解，请检查识别结果。",Toast.LENGTH_LONG).show();
                return;
            }
            dialog.dismiss();
            showSolution(a,solved);
        }));
        dialog.show();
    }

    private void showSolution(int[][] original,int[][] solved){
        FrameLayout box=new FrameLayout(this);
        SudokuResultView result=new SudokuResultView(this);
        result.setData(original,solved);
        box.addView(result,new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        int width=(int)(getResources().getDisplayMetrics().widthPixels*.90f);
        int height=width;
        new AlertDialog.Builder(this)
                .setTitle("数独答案")
                .setView(box,new FrameLayout.LayoutParams(width,height))
                .setPositiveButton("完成",(d,w)->{
                    cropOverlay.setEditingEnabled(true);
                    hint.setText("答案已计算。再次识别时会继续使用上次保存的框选位置。");
                })
                .setNeutralButton("重新识别",(d,w)->{
                    cropOverlay.setEditingEnabled(true);
                    startRecognition();
                })
                .show();
    }

    @Override protected void onDestroy(){
        super.onDestroy();
        executor.shutdownNow();
        if(recognizer!=null) recognizer.close();
    }
}


    @Override
    protected void onDestroy() {
        if (digitRecognizer != null) {
            digitRecognizer.close();
        }
        super.onDestroy();
    }
