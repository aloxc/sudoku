package com.example.sudokusolver;

import android.graphics.Bitmap;
import android.graphics.RectF;

public final class ImageUtils {
    private ImageUtils(){}

    public static Bitmap crop(Bitmap src, RectF normalized) {
        int x=Math.max(0,Math.min(src.getWidth()-1,Math.round(normalized.left*src.getWidth())));
        int y=Math.max(0,Math.min(src.getHeight()-1,Math.round(normalized.top*src.getHeight())));
        int right=Math.max(x+1,Math.min(src.getWidth(),Math.round(normalized.right*src.getWidth())));
        int bottom=Math.max(y+1,Math.min(src.getHeight(),Math.round(normalized.bottom*src.getHeight())));
        return Bitmap.createBitmap(src,x,y,right-x,bottom-y);
    }

    public static Bitmap cell(Bitmap grid, int row, int col) {
        int w=grid.getWidth()/9, h=grid.getHeight()/9;
        int x=col*w, y=row*h;
        int cw=(col==8)?grid.getWidth()-x:w;
        int ch=(row==8)?grid.getHeight()-y:h;
        return Bitmap.createBitmap(grid,x,y,cw,ch);
    }
}
